from pathlib import Path
import base64, json, zipfile
root=Path(__file__).resolve().parent
out=root/'dist';out.mkdir(exist_ok=True)
plugin=out/'ims-woocommerce.zip'
with zipfile.ZipFile(plugin,'w',zipfile.ZIP_DEFLATED) as z:
    for p in (root/'wordpress').rglob('*.php'):z.write(p,p.relative_to(root/'wordpress'))
pixel=(root/'src/pixel.js').read_text()
demo=(root/'src/demo.html').read_text().replace('<!-- IMS_ENGINE -->','<script>'+pixel+'</script>')
(root/'START-HERE.html').write_text(demo)
constants={'PIXEL':pixel,'UI':(root/'src/dashboard.html').read_text(),'DEMO':demo,'WOO_ZIP':base64.b64encode(plugin.read_bytes()).decode()}
bundle='// IMS Universal Purchase Pixel 1.0.0 — paste this entire file into a Cloudflare Worker.\n'
for key,value in constants.items():bundle+='const '+key+' = '+json.dumps(value)+';\n'
bundle+=(root/'src/installers.mjs').read_text().replace('export function installer','function installer')+'\n'
bundle+=(root/'src/worker.mjs').read_text()
(out/'worker.js').write_text(bundle)
print('Built dist/worker.js, dist/ims-woocommerce.zip, START-HERE.html')
