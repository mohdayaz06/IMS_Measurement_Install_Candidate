<?php
/**
 * Plugin Name: IMS Universal Purchase Pixel
 * Description: Routes WooCommerce browser purchases through your IMS tracker. Requires a WP Consent API-compatible consent manager.
 * Version: 1.0.0
 * Author: Insight Media Stream
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;
add_action('admin_menu', function () {
    add_options_page('IMS Pixel', 'IMS Pixel', 'manage_options', 'ims-pixel', 'ims_pixel_settings');
});
add_action('admin_init', function () {
    register_setting('ims_pixel_settings', 'ims_pixel_options', array('sanitize_callback' => function ($input) {
        $url = isset($input['url']) ? esc_url_raw(trim($input['url']), array('https')) : '';
        $id = isset($input['id']) ? sanitize_text_field($input['id']) : '';
        $parts = wp_parse_url($url);
        if (!$url || empty($parts['host']) || !empty($parts['user']) || !empty($parts['pass']) || !empty($parts['query']) || !empty($parts['fragment']) || (!empty($parts['path']) && $parts['path'] !== '/')) {
            add_settings_error('ims_pixel_options', 'url', 'Enter only your HTTPS Worker origin, without a path or query.');
            return get_option('ims_pixel_options', array());
        }
        if (!preg_match('/^[a-f0-9-]{36}$/', $id)) {
            add_settings_error('ims_pixel_options', 'id', 'Enter the client ID from the IMS dashboard.');
            return get_option('ims_pixel_options', array());
        }
        return array('url' => untrailingslashit($url), 'id' => $id);
    }));
});
function ims_pixel_settings() {
    if (!current_user_can('manage_options')) return;
    $o = get_option('ims_pixel_options', array());
    ?>
    <div class="wrap"><h1>IMS Universal Purchase Pixel</h1>
    <p>Enter the Worker URL and client ID generated in your IMS dashboard. Never enter an admin token here.</p>
    <p>Requires WooCommerce and a cookie manager connected to WP Consent API. If browser consent APIs are absent, tracking stays blocked.</p>
    <form method="post" action="options.php"><?php settings_fields('ims_pixel_settings'); ?>
    <table class="form-table"><tr><th>Worker URL</th><td><input class="regular-text" name="ims_pixel_options[url]" type="url" required value="<?php echo esc_attr($o['url'] ?? ''); ?>" placeholder="https://ims-pixel.YOURACCOUNT.workers.dev"></td></tr>
    <tr><th>Client ID</th><td><input class="regular-text" name="ims_pixel_options[id]" required value="<?php echo esc_attr($o['id'] ?? ''); ?>"></td></tr></table>
    <?php submit_button(); ?></form>
    <p>Version 1.0 supports browser events on the classic WooCommerce order-received page. Delayed/offline payments, subscriptions, custom/headless checkouts, and block confirmation templates need separate validation. No server-side purchase webhook is included.</p></div>
    <?php
}
add_action('wp_footer', function () {
    if (!function_exists('WC') || is_admin()) return;
    $o = get_option('ims_pixel_options', array());
    if (empty($o['url']) || empty($o['id'])) return;
    $purchase = null;
    if (function_exists('is_order_received_page') && is_order_received_page()) {
        $order = wc_get_order(absint(get_query_var('order-received')));
        $key = isset($_GET['key']) ? sanitize_text_field(wp_unslash($_GET['key'])) : '';
        // Do not disclose order amounts without the secret order key or mark pending payments as paid.
        if ($order && $key && hash_equals($order->get_order_key(), $key) && $order->is_paid()) {
            $purchase = array('order_id' => (string) $order->get_id(), 'value' => (float) $order->get_total(), 'currency' => $order->get_currency());
        }
    }
    $settings = array('baseUrl' => $o['url'], 'clientId' => $o['id']);
    ?>
    <script>
    (function(){
      const options=<?php echo wp_json_encode($settings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
      const purchase=<?php echo wp_json_encode($purchase, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
      let ready, tries=0;
      function tracker(){
        if(!ready) ready=new Promise((resolve,reject)=>{
          const s=document.createElement('script');s.src=options.baseUrl+'/pixel.js';s.async=true;
          s.onload=()=>resolve(window.IMSPixel.create({...options,onResult:r=>console.info('[IMS]',r)}));
          s.onerror=()=>{ready=null;reject(new Error('IMS script failed to load'));};document.head.appendChild(s);
        });
        return ready;
      }
      async function run(){
        if(typeof window.wp_has_consent!=='function')return;
        const consent={analytics:window.wp_has_consent('statistics')===true,marketing:window.wp_has_consent('marketing')===true};
        if(!consent.analytics&&!consent.marketing)return;
        try{const p=await tracker();await p.pageView({page_url:location.href},consent);
          if(purchase)await p.purchase({...purchase,page_url:location.href},consent);
        }catch(e){console.error('[IMS]',e.message);}
      }
      document.addEventListener('wp_listen_for_consent_change',run);
      const timer=setInterval(()=>{if(typeof window.wp_has_consent==='function'){clearInterval(timer);run();}
        else if(++tries>=100){clearInterval(timer);console.info('[IMS] No WP Consent API; tracking remains blocked.');}},100);
    })();
    </script>
    <?php
}, 99);
