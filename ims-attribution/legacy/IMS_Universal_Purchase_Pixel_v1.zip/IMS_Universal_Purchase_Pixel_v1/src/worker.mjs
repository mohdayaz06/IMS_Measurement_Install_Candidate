// Bundled into dist/worker.js by build.py. No npm packages required.
const headers = {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY'};
function response(body, status=200, type='application/json', extra={}) {
 return new Response(type==='application/json'?JSON.stringify(body):body,{status,headers:{...headers,'Content-Type':type+'; charset=utf-8',...extra}});
}
function validate(input) {
 const text=(v,n=200)=>String(v||'').trim().slice(0,n);
 const domains=Array.isArray(input.domains)?input.domains.map(x=>text(x).toLowerCase()):[];
 if (!text(input.name)) throw new Error('Client name is required');
 if (!domains.length || domains.length>20 || domains.some(x=>!/^([a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/.test(x))) throw new Error('Enter exact hostnames, e.g. store.com and www.store.com, without https://');
 const mode=input.google?.mode || 'none';
 if(!['none','ga4','ads'].includes(mode)) throw new Error('Invalid Google mode');
 const google={mode,id:text(input.google?.id),adsId:text(input.google?.adsId),label:text(input.google?.label)};
 if(mode==='ga4' && !/^G-[A-Z0-9]+$/.test(google.id)) throw new Error('GA4 ID must start G-');
 if(mode==='ads' && (!/^AW-\d+$/.test(google.adsId)||! /^[A-Za-z0-9_-]+$/.test(google.label))) throw new Error('Google Ads needs AW-number and conversion label');
 const metaId=text(input.metaId);
 if(metaId && !/^\d{5,30}$/.test(metaId)) throw new Error('Meta pixel ID must contain digits only');
 const simpli={url:text(input.simpli?.url,3000),type:input.simpli?.type==='script'?'script':'image'};
 if(simpli.url){
  if(!simpli.url.includes('{{value}}')||!simpli.url.includes('{{order_id}}')) throw new Error('Simpli.fi URL must contain {{value}} and {{order_id}} in the vendor-approved parameter positions');
  const u=new URL(simpli.url.replace(/\{\{(value|order_id|currency)\}\}/g,'TEST'));
  if(u.protocol!=='https:'||u.username||u.password||u.hash||!(u.hostname==='simpli.fi'||u.hostname.endsWith('.simpli.fi'))) throw new Error('Use a complete HTTPS conversion URL on simpli.fi supplied by Simpli.fi; not an HTML snippet');
  if(/\{\{|\}\}/.test(simpli.url.replace(/\{\{(value|order_id|currency)\}\}/g,''))) throw new Error('Unrecognized Simpli.fi placeholder');
 }
 if(input.live && mode==='none'&&!metaId&&!simpli.url) throw new Error('Configure a destination before enabling Live');
 return {name:text(input.name),domains:[...new Set(domains)],enabled:input.enabled!==false,live:input.live===true,google,metaId,simpli};
}
async function authorized(request, env) {
 if(!env.ADMIN_TOKEN || env.ADMIN_TOKEN.length<24) return false;
 const token=request.headers.get('authorization')||'';
 const digest=async s=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const [a,b]=await Promise.all([digest(token),digest('Bearer '+env.ADMIN_TOKEN)]);
 let difference=0; for(let i=0;i<a.length;i++) difference|=a[i]^b[i]; return difference===0;
}
export default {
 async fetch(request,env) {
  const url=new URL(request.url), path=url.pathname;
  try {
   if(path==='/pixel.js' && request.method==='GET') return response(PIXEL,200,'application/javascript',{'Access-Control-Allow-Origin':'*','Cross-Origin-Resource-Policy':'cross-origin'});
   if(path==='/' && request.method==='GET') return response(UI,200,'text/html',{'Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"});
   if(path==='/demo' && request.method==='GET') return response(DEMO,200,'text/html',{'Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors *; base-uri 'none'",'X-Frame-Options':'SAMEORIGIN'});
   if(path==='/health') return response({app:'IMS Universal Pixel',version:'1.0.0',configured:!!env.CONFIGS && !!env.ADMIN_TOKEN && env.ADMIN_TOKEN.length>=24});
   if(path.startsWith('/public/config/')){
    const cors={'Access-Control-Allow-Origin':'*','Cross-Origin-Resource-Policy':'cross-origin'};
    if(request.method==='OPTIONS') return response('',204,'text/plain',{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, OPTIONS'});
    if(request.method!=='GET') return response({error:'Method not allowed'},405);
    const id=path.slice('/public/config/'.length);
    if(!/^[a-f0-9-]{36}$/.test(id)) return response({error:'Invalid client ID'},400,'application/json',cors);
    if(!env.CONFIGS) return response({error:'Add CONFIGS KV binding'},503,'application/json',cors);
    const config=await env.CONFIGS.get('client:'+id,'json');
    if(!config) return response({error:'Client not found'},404,'application/json',cors);
    // Destination IDs are public, as with normal client-side tags. Never store API secrets here.
    const {name,updatedAt,...publicConfig}=config;
    return response(publicConfig,200,'application/json',cors);
   }
   if(path.startsWith('/api/')){
    if(!await authorized(request,env)) return response({error:'Invalid admin token, or ADMIN_TOKEN secret is missing/shorter than 24 characters'},401);
    if(!env.CONFIGS) return response({error:'Add a KV namespace binding named CONFIGS'},503);
    if(path==='/api/clients' && request.method==='GET'){
     let cursor; const keys=[];
     do {const page=await env.CONFIGS.list({prefix:'client:',limit:1000,...(cursor?{cursor}:{})}); keys.push(...page.keys);cursor=page.list_complete?undefined:page.cursor;}while(cursor);
     const clients=(await Promise.all(keys.map(k=>env.CONFIGS.get(k.name,'json')))).filter(Boolean);
     return response({clients});
    }
    const match=path.match(/^\/api\/clients\/([a-f0-9-]{36})$/);
    if(path==='/api/clients' && request.method==='POST' || match && request.method==='PUT'){
     if(Number(request.headers.get('content-length')||0)>16000) return response({error:'Config too large'},413);
     const body=await request.text(); if(body.length>16000)return response({error:'Config too large'},413);
     let input;try{input=JSON.parse(body);}catch(_){return response({error:'Invalid JSON'},400);}
     let c;try{c=validate(input);}catch(e){return response({error:e.message},400);}
     c.id=match?match[1]:crypto.randomUUID();c.updatedAt=new Date().toISOString();
     await env.CONFIGS.put('client:'+c.id,JSON.stringify(c));return response(c);
    }
    if(match && request.method==='DELETE'){await env.CONFIGS.delete('client:'+match[1]);return response({deleted:true});}
    if(path==='/api/install' && request.method==='GET'){
     const id=url.searchParams.get('client'); if(!/^[a-f0-9-]{36}$/.test(id||'')) return response({error:'Invalid client'},400);
     if(!await env.CONFIGS.get('client:'+id))return response({error:'Client not found'},404);
     let code;try{code=installer(url.searchParams.get('platform'),url.origin,id);}catch(e){return response({error:e.message},400);}
     return response({code});
    }
    if(path==='/api/woocommerce.zip' && request.method==='GET'){
     const bytes=Uint8Array.from(atob(WOO_ZIP),c=>c.charCodeAt(0));
     return new Response(bytes,{headers:{...headers,'Content-Type':'application/zip','Content-Disposition':'attachment; filename="ims-woocommerce.zip"'}});
    }
    return response({error:'Not found'},404);
   }
   return response({error:'Not found'},404);
  }catch(e){return response({error:'Server error. Check bindings and configuration.'},500);}
 }
};
