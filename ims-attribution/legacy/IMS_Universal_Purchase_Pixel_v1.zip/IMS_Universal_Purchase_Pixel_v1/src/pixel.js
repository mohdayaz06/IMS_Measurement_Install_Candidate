/* IMS Universal Purchase Pixel v1.0 — browser routing, not server-side attribution. */
(function (w) {
  'use strict';
  if (w.IMSPixel) return;
  const loaders = new Map(), googleTargets = new Set(), metaTargets = new Set();
  const retained = new Set();
  const TTL = 30 * 86400000;
  function script(src) {
    if (loaders.has(src)) return loaders.get(src);
    const promise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.async = true; s.src = src;
      const timeout = setTimeout(() => { s.remove(); reject(new Error('Script load timed out: ' + new URL(src).hostname)); }, 8000);
      s.onload = () => { clearTimeout(timeout); resolve(); };
      s.onerror = () => { clearTimeout(timeout); reject(new Error('Script blocked or failed to load: ' + new URL(src).hostname)); };
      document.head.appendChild(s);
    });
    loaders.set(src, promise);
    promise.catch(() => loaders.delete(src));
    return promise;
  }
  function cleanURL(input) {
    const url = new URL(input);
    if (!/^https?:$/.test(url.protocol)) throw new Error('Expected an HTTP(S) page URL');
    // Never forward arbitrary query strings, order keys, email addresses, or fragments.
    const safe = new URL(url.origin + url.pathname);
    for (const key of ['gclid', 'gbraid', 'wbraid', 'fbclid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term']) {
      if (url.searchParams.has(key)) safe.searchParams.set(key, url.searchParams.get(key));
    }
    return safe.href;
  }
  function normalize(raw) {
    const orderId = String(raw.order_id == null ? '' : raw.order_id).trim();
    if (!orderId || orderId.length > 160) throw new Error('A valid order_id is required');
    if (raw.value === null || String(raw.value).trim() === '' || typeof raw.value === 'boolean' || raw.value === undefined) throw new Error('A numeric purchase value is required');
    const value = Number(raw.value), currency = String(raw.currency || '').toUpperCase();
    if (!Number.isFinite(value) || value < 0) throw new Error('Purchase value must be a nonnegative number');
    if (!/^[A-Z]{3}$/.test(currency)) throw new Error('Currency must be a three-letter ISO code');
    return {order_id: orderId, value: Math.round(value * 1000000) / 1000000, currency};
  }
  function google(c, consent, page) {
    w.dataLayer = w.dataLayer || [];
    w.gtag = w.gtag || function () { w.dataLayer.push(arguments); };
    w.gtag('consent', 'update', {analytics_storage: consent.analytics ? 'granted' : 'denied', ad_storage: consent.marketing ? 'granted' : 'denied', ad_user_data: consent.marketing ? 'granted' : 'denied', ad_personalization: consent.marketing ? 'granted' : 'denied'});
    const id = c.google.mode === 'ga4' ? c.google.id : c.google.adsId;
    if (!googleTargets.has(id)) {
      w.gtag('js', new Date());
      w.gtag('config', id, {send_page_view: false, page_location: page, cookie_domain: new URL(page).hostname, allow_google_signals: false, allow_ad_personalization_signals: consent.marketing});
      googleTargets.add(id);
    }
    return script('https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(id));
  }
  async function meta(c) {
    if (!w.fbq) {
      const f = w.fbq = function () { f.callMethod ? f.callMethod.apply(f, arguments) : f.queue.push(arguments); };
      if (!w._fbq) w._fbq = f;
      f.push = f; f.loaded = true; f.version = '2.0'; f.queue = [];
    }
    if (!metaTargets.has(c.metaId)) {
      // Avoid Meta's automatic button/microdata event collection.
      w.fbq('set', 'autoConfig', false, c.metaId);
      w.fbq('init', c.metaId); metaTargets.add(c.metaId);
    }
    await script('https://connect.facebook.net/en_US/fbevents.js');
  }
  function simpliURL(template, p) {
    return template.replace(/\{\{(value|order_id|currency)\}\}/g, (_, key) => encodeURIComponent(String(p[key])));
  }
  async function simpli(c, p) {
    const url = simpliURL(c.simpli.url, p);
    if (c.simpli.type === 'script') {
      // A conversion URL must execute for every distinct order; do not use the SDK cache.
      await new Promise((resolve, reject) => {
        const el = document.createElement('script'); el.async = true; el.src = url;
        const timeout = setTimeout(() => { el.remove(); reject(new Error('Simpli.fi request timed out')); }, 8000);
        el.onload = () => { clearTimeout(timeout); el.remove(); resolve(); };
        el.onerror = () => { clearTimeout(timeout); el.remove(); reject(new Error('Simpli.fi script request failed')); };
        document.head.appendChild(el);
      });
    } else {
      await new Promise((resolve, reject) => {
        const img = new Image(); retained.add(img);
        const timeout = setTimeout(() => { retained.delete(img); reject(new Error('Simpli.fi request timed out')); }, 8000);
        img.onload = () => { clearTimeout(timeout); retained.delete(img); resolve(); };
        img.onerror = () => { clearTimeout(timeout); retained.delete(img); reject(new Error('Simpli.fi image response failed; verify request in platform')); };
        img.src = url;
      });
    }
  }
  function create(options) {
    const base = String(options.baseUrl).replace(/\/$/, ''), id = options.clientId;
    if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('Invalid IMS client ID');
    const memory = new Map(); let queue = Promise.resolve();
    const storage = options.storage || {
      getItem: key => { try { return w.localStorage.getItem(key); } catch (_) { return null; } },
      setItem: (key, value) => { try { w.localStorage.setItem(key, value); } catch (_) {} }
    };
    async function config() {
      const response = await fetch(base + '/public/config/' + id, {credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer'});
      if (!response.ok) throw new Error('Client config unavailable (' + response.status + ')');
      return response.json();
    }
    async function seen(key) {
      if (memory.has(key)) return true;
      try { const v = Number(await storage.getItem(key)); return v > 0 && Date.now() - v < TTL; } catch (_) { return false; }
    }
    async function mark(key) {
      memory.set(key, true);
      try { await storage.setItem(key, String(Date.now())); } catch (_) {}
    }
    async function send(type, raw, consent, preview, configOverride) {
      const purchase = type === 'purchase' ? normalize(raw) : null;
      const page = cleanURL(raw.page_url || w.location.href);
      const c = configOverride || await config();
      if (!c.enabled) return {status: 'disabled', destinations: []};
      const host = new URL(page).hostname.toLowerCase();
      if (!preview && !c.domains.includes(host)) throw new Error('Store hostname is not in this client’s allowed domains: ' + host);
      const plans = [];
      if (c.google.mode === 'ga4') plans.push({destination: 'GA4', permitted: consent.analytics === true, target: c.google.id});
      if (c.google.mode === 'ads') plans.push({destination: 'Google Ads', permitted: consent.marketing === true, target: c.google.adsId + '/' + c.google.label});
      if (c.metaId) plans.push({destination: 'Meta', permitted: consent.marketing === true, target: c.metaId});
      if (c.simpli.url && type === 'purchase') plans.push({destination: 'Simpli.fi', permitted: consent.marketing === true, target: c.simpli.url});
      const results = [];
      for (const plan of plans) {
        const result = {destination: plan.destination, status: 'consent-blocked'};
        if (!plan.permitted) { results.push(result); continue; }
        if (preview || !c.live) {
          result.status = 'preview-only';
          result.payload = plan.destination === 'Simpli.fi' ? {url: simpliURL(c.simpli.url, purchase), type: c.simpli.type} : {event: type === 'purchase' ? (plan.destination === 'Meta' ? 'Purchase' : (plan.destination === 'Google Ads' ? 'conversion' : 'purchase')) : 'page_view', ...purchase, page_url: page, target: plan.target};
          results.push(result); continue;
        }
        const key = 'ims:v1:' + id + ':' + plan.destination + ':' + encodeURIComponent(plan.target) + ':' + (purchase ? encodeURIComponent(purchase.order_id) : '');
        if (purchase && await seen(key)) { result.status = 'duplicate-suppressed'; results.push(result); continue; }
        try {
          if (plan.destination === 'GA4' || plan.destination === 'Google Ads') {
            await google(c, consent, page);
            if (type === 'page_view') {
              if (plan.destination === 'GA4') w.gtag('event', 'page_view', {send_to: c.google.id, page_location: page});
              result.status = plan.destination === 'GA4' ? 'queued-to-sdk' : 'tag-initialized';
            } else {
              w.gtag('event', plan.destination === 'GA4' ? 'purchase' : 'conversion', {send_to: plan.target, transaction_id: purchase.order_id, value: purchase.value, currency: purchase.currency, page_location: page, ...(plan.destination === 'GA4' ? {items: []} : {})});
              result.status = 'queued-to-sdk';
            }
          } else if (plan.destination === 'Meta') {
            await meta(c);
            if (type === 'purchase') w.fbq('trackSingle', c.metaId, 'Purchase', {value: purchase.value, currency: purchase.currency, order_id: purchase.order_id}, {eventID: 'ims-' + id + '-' + purchase.order_id});
            else w.fbq('trackSingle', c.metaId, 'PageView');
            result.status = 'queued-to-sdk';
          } else { await simpli(c, purchase); result.status = 'request-loaded'; }
          if (purchase) await mark(key);
        } catch (e) { result.status = 'error'; result.error = e.message; }
        results.push(result);
      }
      // These results are local diagnostics, NEVER a claim of platform receipt or attribution.
      const report = {status: preview || !c.live ? 'preview' : 'dispatch-attempted', type, ...(purchase || {}), destinations: results};
      if (typeof options.onResult === 'function') options.onResult(report);
      return report;
    }
    function serialized(fn) { const p = queue.then(fn); queue = p.catch(() => {}); return p; }
    return {
      purchase: (data, consent = {}) => serialized(() => send('purchase', data, consent, false)),
      pageView: (data = {}, consent = {}) => serialized(() => send('page_view', data, consent, false)),
      // Unconditionally safe even if the client's live switch is enabled.
      preview: (data, consent = {analytics: true, marketing: true}) => send('purchase', data, consent, true),
      previewConfig: (c, data, consent = {analytics: true, marketing: true}) => send('purchase', data, consent, true, c)
    };
  }
  w.IMSPixel = {version: '1.0.0', create};
})(window);
