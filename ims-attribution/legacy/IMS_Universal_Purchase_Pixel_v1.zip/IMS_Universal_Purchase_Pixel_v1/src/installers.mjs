export function installer(platform, baseUrl, clientId) {
  const base = JSON.stringify(baseUrl), id = JSON.stringify(clientId);
  const ready = `const imsReady = new Promise((resolve, reject) => {
  const s = document.createElement('script'); s.src = ${base} + '/pixel.js'; s.async = true;
  s.onload = () => resolve(window.IMSPixel.create({baseUrl:${base}, clientId:${id}${platform === 'shopify' ? ', storage: browser.localStorage' : ''}, onResult:r=>console.info('[IMS]', r)}));
  s.onerror = () => reject(new Error('IMS tracker failed to load'));
  document.head.appendChild(s);
});
imsReady.catch(e => console.error('[IMS]', e.message));`;
  if (platform === 'shopify') return `// IMS Shopify Custom Pixel — paste JavaScript only, WITHOUT <script> tags.
// Set Customer privacy to require Marketing AND Analytics; configure Data sale appropriately.
// Keep the IMS client in Preview until a development-store checkout is verified.
${ready}
let imsPrivacy = init.customerPrivacy || {};
const imsConsent = () => ({analytics:imsPrivacy.analyticsProcessingAllowed === true,
  marketing:imsPrivacy.marketingAllowed === true && imsPrivacy.saleOfDataAllowed === true});
if (typeof api !== 'undefined' && api.customerPrivacy) {
  api.customerPrivacy.subscribe('visitorConsentCollected', e => { imsPrivacy = e.customerPrivacy || {}; });
}
analytics.subscribe('page_viewed', async e => {
  try { const p = await imsReady; await p.pageView({page_url:e.context.document.location.href}, imsConsent()); }
  catch(err){console.error('[IMS]', err.message);}
});
analytics.subscribe('checkout_completed', async e => {
  try {
    const c = e.data.checkout;
    if (!c.order || !c.order.id) throw new Error('Shopify event has no order ID; skipped');
    const p = await imsReady;
    await p.purchase({order_id:String(c.order.id), value:c.totalPrice.amount,
      currency:c.currencyCode, page_url:e.context.document.location.href}, imsConsent());
  } catch(err){console.error('[IMS]', err.message);}
});`;
  if (platform === 'bigcommerce') return `<script>
// IMS BigCommerce Stencil + BODL. Enable Big Open Data Layer and cookie consent tracking.
// Script Manager: All pages, Head, Script category Functional (this bootstrap only listens;
// advertising SDKs remain blocked until BODL reports explicit consent).
(function(){
${ready}
let consent={analytics:false,marketing:false}, subscribed=false;
function privacy(p){
  const next={analytics:p.analytics===true,marketing:p.advertising===true};
  const gained=(next.analytics&&!consent.analytics)||(next.marketing&&!consent.marketing);
  consent=next;
  if(gained) imsReady.then(t=>t.pageView({page_url:location.href},consent)).catch(e=>console.error('[IMS]',e.message));
}
function subscribe(){
  const b=window.bodlEvents;
  if(subscribed || !b || !b.checkout || !b.consent) return false;
  if(typeof b.checkout.orderPurchased!=='function') return false;
  subscribed=true;
  if(typeof b.consent.loaded==='function') b.consent.loaded(privacy);
  if(typeof b.consent.updated==='function') b.consent.updated(privacy);
  b.checkout.orderPurchased(async p=>{
    try {const t=await imsReady; await t.purchase({order_id:p.order_id,value:p.cart_value,
      currency:p.currency,page_url:location.href},consent);}
    catch(e){console.error('[IMS]',e.message);}
  });
  return true;
}
if(!subscribe()){
  let tries=0;
  const timer=setInterval(()=>{if(subscribe() || ++tries>=100){clearInterval(timer);
    if(!subscribed) console.error('[IMS] BODL unavailable. Enable Big Open Data Layer on a Stencil storefront.');
  }},100);
}
})();
</script>`;
  if (platform === 'duda') return `<div style="font-family:Arial;padding:24px;border:1px solid #ccc;border-radius:12px">
<h3>IMS purchase tracking preview</h3>
<p>This demonstration never sends a purchase to advertising platforms.</p>
<label>Order value <input id="ims-value" type="number" min="0" step="0.01" value="149.95"></label>
<button id="ims-test" type="button">Preview purchase</button>
<pre id="ims-result" style="white-space:pre-wrap;overflow-wrap:anywhere"></pre>
</div>
<script>
(function(){
${ready}
document.getElementById('ims-test').onclick=async function(){
 const output=document.getElementById('ims-result');
 try {const tracker=await imsReady;
  output.textContent=JSON.stringify(await tracker.preview({order_id:'DEMO-'+Date.now(),
   value:document.getElementById('ims-value').value,currency:'USD',page_url:location.href}),null,2);
 }catch(e){output.textContent=e.message;}
};
})();
</script>`;
  throw new Error('Unknown platform');
}
