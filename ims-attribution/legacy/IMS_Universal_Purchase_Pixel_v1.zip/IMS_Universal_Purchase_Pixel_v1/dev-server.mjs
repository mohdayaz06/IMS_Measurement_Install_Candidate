// Local preview only. Bound to loopback, never expose this server to the internet.
import http from 'node:http';
import crypto from 'node:crypto';
import {readFile,writeFile,rename} from 'node:fs/promises';
import worker from './dist/worker.js';
const file=new URL('./.local-configs.json',import.meta.url);let data={};
try{data=JSON.parse(await readFile(file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
let writes=Promise.resolve();
const persist=()=>{writes=writes.then(async()=>{await writeFile(new URL('./.local-configs.tmp',import.meta.url),JSON.stringify(data,null,2),{mode:0o600});await rename(new URL('./.local-configs.tmp',import.meta.url),file);});return writes;};
const kv={async get(k,type){const v=data[k];return v===undefined?null:(type==='json'?JSON.parse(v):v);},async put(k,v){data[k]=v;await persist();},async delete(k){delete data[k];await persist();},async list({prefix}){return {keys:Object.keys(data).filter(k=>k.startsWith(prefix)).map(name=>({name})),list_complete:true};}};
const token=process.env.IMS_ADMIN_TOKEN||crypto.randomBytes(24).toString('hex');
const env={CONFIGS:kv,ADMIN_TOKEN:token};
const server=http.createServer(async(req,res)=>{try{let chunks=[],size=0;for await(const c of req){size+=c.length;if(size>20000){res.writeHead(413);res.end();return;}chunks.push(c);}const body=Buffer.concat(chunks);const r=await worker.fetch(new Request('http://127.0.0.1:8787'+req.url,{method:req.method,headers:req.headers,...(body.length?{body}: {})}),env);res.writeHead(r.status,Object.fromEntries(r.headers));res.end(Buffer.from(await r.arrayBuffer()));}catch(e){res.writeHead(500);res.end('Local server error');}});
server.listen(8787,'127.0.0.1',()=>{console.log('Local dashboard: http://127.0.0.1:8787');console.log('Admin token: '+token);console.log('Loopback preview only. Use Cloudflare for store installation.');});
