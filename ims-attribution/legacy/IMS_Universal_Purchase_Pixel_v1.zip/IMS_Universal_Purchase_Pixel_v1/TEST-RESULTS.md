# Validation — IMS Universal Purchase Pixel 1.0

Local validation performed October 28, 2026.

- 22 automated Node tests passed (`npm test`).
- JavaScript syntax check passed for the bundled Worker.
- DOM interface checks passed for offline demo, consent controls, dashboard login, client save, routing preview, all four installer choices, logout, and guide token generation.
- Store adapter tests use mocked Shopify and BODL events.
- Preview was verified to load no vendor SDKs, dispatch no vendor conversion requests, and write no order-deduplication records.

## Not verified

- Real Shopify/BigCommerce/WooCommerce checkout, including store-specific app conflicts and revenue conventions.
- Actual Google Ads/GA4, Meta or Simpli.fi event receipt, revenue acceptance, or campaign attribution.
- Cloudflare deployment in a user account.
- PHP/WordPress plugin execution; PHP was not installed in this environment.
- Visual rendering and mobile layout in a real browser; interface checks used a DOM emulator.

All initial delivery validation should use development stores and dedicated test destinations. Nothing was installed on Barnett or another client store.
