# IMS Universal Purchase Pixel 1.0

Open **START-HERE.html** for an offline working preview. Open **INSTALL.html** for the full browser-only deployment and store instructions.

This is a new, deployable browser purchase router with remote per-client configuration. It is not a live deployment and does not modify Barnett's site or the older SASS project.

## Included

- Cloudflare Worker dashboard and KV-backed configuration API.
- GA4 (with an existing Google Ads import) OR direct Google Ads purchase route.
- Meta browser Purchase events with value/currency/event ID.
- Simpli.fi vendor-supplied IMG/external SCRIPT conversion URL adapter. Exact vendor endpoint/parameters are required; arbitrary inline tags are not supported.
- Shopify Customer Events installer; BigCommerce Stencil/BODL installer; WooCommerce plugin; Duda non-sending preview widget.
- Local safe preview, explicit consent gates, and best-effort per-browser/destination/order duplicate suppression.

## Browser-only deployment

Paste `dist/worker.js` into a Cloudflare Worker's code editor. Bind KV as `CONFIGS`, add an `ADMIN_TOKEN` secret of 24+ random characters, deploy, and open the Worker URL. Full steps: `INSTALL.html`.

The WordPress plugin ZIP is `dist/ims-woocommerce.zip`. The outer download is a source package, not an uploadable WordPress plugin.

## Development

Requires Node 20+ and Python 3; no npm install is needed for the app/tests.

```
python3 build.py
npm test
npm start
```

The local server is loopback-only. Keep local config files, tokens, and `.env` files private. No real credentials are included.

## Important boundaries

No server-side tracking/CAPI, spend integration, unified ROAS, customer matching, refunds, guaranteed delivery, central purchase database, or cross-platform attribution deduplication. Native server tracking quality is not reproduced. Store adapters and vendor attribution require merchant-by-merchant validation before cutover. Simpli.fi requires a compatible account-specific endpoint. PHP/WordPress execution and real client accounts were not available for live testing.

Source sources and detailed acceptance/rollback instructions are in INSTALL.html.
