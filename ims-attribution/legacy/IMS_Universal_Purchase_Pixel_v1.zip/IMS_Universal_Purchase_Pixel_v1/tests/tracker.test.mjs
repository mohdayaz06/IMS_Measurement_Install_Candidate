import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const source=await readFile(new URL('../src/pixel.js',import.meta.url),'utf8');
const id='11111111-1111-4111-8111-111111111111';
function config(extra={}){return {id,enabled:true,live:true,domains:['store.example'],google:{mode:'ga4',id:'G-TEST123'},metaId:'123456789',simpli:{url:'https://tag.simpli.fi/conversion?value={{value}}&order_id={{order_id}}&currency={{currency}}',type:'image'},...extra};}
function harness(c=config(), failHost=''){
 const calls=[],saved=new Map();
 const document={head:{appendChild(s){calls.push({kind:'script',src:s.src});queueMicrotask(()=>s.src.includes(failHost)&&failHost?s.onerror():s.onload());}},createElement(){return {remove(){}};}};
 class Image{set src(v){calls.push({kind:'image',src:v});queueMicrotask(()=>this.onload());}}
 const w={location:{href:'https://store.example/thank-you?email=private@example.com&gclid=TESTCLICK#secret'},localStorage:{getItem:k=>saved.get(k)||null,setItem:(k,v)=>saved.set(k,v)},gtag(...args){calls.push({kind:'google',args});},fbq(...args){calls.push({kind:'meta',args});}};
 const context={window:w,document,Image,fetch:async()=>({ok:true,json:async()=>c}),URL,Map,Set,Promise,Date,Number,String,Error,console,setTimeout,clearTimeout};
 vm.runInNewContext(source,context);return {p:w.IMSPixel.create({baseUrl:'https://tracker.example',clientId:id}),w,calls,saved};
}
const event={order_id:'ORDER-001',value:'149.95',currency:'usd'};
const consent={analytics:true,marketing:true};
test('one purchase routes numeric value/currency/order ID to three destinations',async()=>{
 const h=harness();const r=await h.p.purchase(event,consent);assert.equal(r.destinations.length,3);
 assert.deepEqual(Array.from(r.destinations,x=>x.status),['queued-to-sdk','queued-to-sdk','request-loaded']);
 const g=h.calls.find(x=>x.kind==='google'&&x.args[1]==='purchase').args[2];assert.equal(g.value,149.95);assert.equal(g.transaction_id,'ORDER-001');assert.equal(g.currency,'USD');assert(!g.page_location.includes('email'));assert(!g.page_location.includes('#'));assert(g.page_location.includes('gclid=TESTCLICK'));
 const m=h.calls.find(x=>x.kind==='meta'&&x.args[2]==='Purchase').args;assert.equal(m[0],'trackSingle');assert.equal(m[3].value,149.95);assert.equal(m[4].eventID,'ims-'+id+'-ORDER-001');
 assert(h.calls.find(x=>x.kind==='image').src.includes('order_id=ORDER-001'));
});
test('direct Google Ads sends conversion to ID/label instead of GA4 purchase',async()=>{const h=harness(config({google:{mode:'ads',adsId:'AW-12345',label:'LABEL'},metaId:'',simpli:{url:''}}));await h.p.purchase(event,consent);const args=h.calls.find(x=>x.kind==='google'&&x.args[1]==='conversion').args;assert.equal(args[2].send_to,'AW-12345/LABEL');assert(!h.calls.some(x=>x.kind==='google'&&x.args[1]==='purchase'));});
test('preview is safe even with live config and does not reserve order IDs',async()=>{const h=harness();const p=await h.p.preview(event);assert.equal(p.status,'preview');assert.equal(h.calls.length,0);assert.equal(h.saved.size,0);const live=await h.p.purchase(event,consent);assert.equal(live.destinations[0].status,'queued-to-sdk');});
test('preview config bypasses domain check and requires no config fetch',async()=>{const h=harness();const r=await h.p.previewConfig(config({domains:['other.example']}),event);assert.equal(r.status,'preview');assert.equal(h.calls.length,0);});
test('preview mode client never loads SDKs even via purchase()',async()=>{const h=harness(config({live:false}));const r=await h.p.purchase(event,consent);assert.equal(r.status,'preview');assert.equal(h.calls.length,0);});
test('no permission defaults to no tracking or storage',async()=>{const h=harness();const r=await h.p.purchase(event);assert(r.destinations.every(x=>x.status==='consent-blocked'));assert.equal(h.calls.length,0);assert.equal(h.saved.size,0);});
test('analytics-only allows GA4 but blocks Meta and Simpli.fi',async()=>{const h=harness();const r=await h.p.purchase(event,{analytics:true,marketing:false});assert.equal(r.destinations[0].status,'queued-to-sdk');assert.equal(r.destinations[1].status,'consent-blocked');assert(!h.calls.some(x=>x.kind==='meta'||x.kind==='image'));const update=h.calls.find(x=>x.kind==='google'&&x.args[0]==='consent');assert.equal(update.args[2].ad_storage,'denied');});
test('duplicate suppression is per order and destination, including concurrent calls',async()=>{const h=harness();const [a,b]=await Promise.all([h.p.purchase(event,consent),h.p.purchase(event,consent)]);assert(a.destinations.every(x=>x.status!=='duplicate-suppressed'));assert(b.destinations.every(x=>x.status==='duplicate-suppressed'));assert.equal(h.calls.filter(x=>x.kind==='image').length,1);await h.p.purchase({...event,order_id:'ORDER-002'},consent);assert.equal(h.calls.filter(x=>x.kind==='image').length,2);});
test('denied destinations can fire later after permission without refiring GA4',async()=>{const h=harness();await h.p.purchase(event,{analytics:true});const r=await h.p.purchase(event,consent);assert.equal(r.destinations[0].status,'duplicate-suppressed');assert.equal(r.destinations[1].status,'queued-to-sdk');});
test('client storage namespaces prevent one client suppressing another',async()=>{const h=harness();await h.p.purchase(event,consent);assert([...h.saved.keys()].every(k=>k.startsWith('ims:v1:'+id+':')));});
test('disabled client produces no platform calls',async()=>{const h=harness(config({enabled:false}));assert.equal((await h.p.purchase(event,consent)).status,'disabled');assert.equal(h.calls.length,0);});
test('wrong domain fails closed',async()=>{const h=harness(config({domains:['different.example']}));await assert.rejects(()=>h.p.purchase(event,consent),/hostname/);assert.equal(h.calls.length,0);});
test('bad amounts/IDs/currency are rejected; zero value is allowed',async()=>{for(const bad of [{value:''},{value:null},{value:-1},{value:'NaN'},{value:true},{order_id:''},{currency:'DOLLARS'}]){const h=harness();await assert.rejects(()=>h.p.purchase({...event,...bad},consent));assert.equal(h.calls.length,0);}const h=harness();assert.equal((await h.p.purchase({...event,value:0},consent)).value,0);});
test('blocked Google SDK does not stop other destinations or mark Google as sent',async()=>{const h=harness(config(),'googletagmanager.com');const r=await h.p.purchase(event,consent);assert.equal(r.destinations[0].status,'error');assert.equal(r.destinations[1].status,'queued-to-sdk');assert.equal(r.destinations[2].status,'request-loaded');assert(![...h.saved.keys()].some(k=>k.includes(':GA4:')));});
test('Simpli.fi URL escapes order IDs and script endpoint runs per distinct order',async()=>{const c=config({google:{mode:'none'},metaId:'',simpli:{type:'script',url:'https://tag.simpli.fi/conv?v={{value}}&o={{order_id}}'}});const h=harness(c);await h.p.purchase({...event,order_id:'A&B/#'},consent);await h.p.purchase({...event,order_id:'B'},consent);const scripts=h.calls.filter(x=>x.kind==='script');assert.equal(scripts.length,2);assert(scripts[0].src.includes('A%26B%2F%23'));});
